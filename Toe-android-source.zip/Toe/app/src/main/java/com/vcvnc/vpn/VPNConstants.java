package com.vcvnc.vpn;

import android.os.Environment;

/**
 * Created by minhui.zhu on 2017/6/24.
 * Copyright © 2017年 minhui.zhu. All rights reserved.
 */

public interface VPNConstants {
    String VPN_SP_NAME = "vpn_sp_name";
    String DEFAULT_PACKAGE_ID = "default_package_id";
}
